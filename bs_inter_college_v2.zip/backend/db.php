<?php
$conn=new mysqli("localhost","root","","school_db");
?>