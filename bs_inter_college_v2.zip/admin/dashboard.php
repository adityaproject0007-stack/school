<?php session_start(); if(!isset($_SESSION['admin'])) die("Login First"); ?>
<h1>Admin Panel</h1>
<ul>
<li>Manage Students</li>
<li>Fees</li>
<li>Results</li>
<li>Attendance</li>
</ul>
