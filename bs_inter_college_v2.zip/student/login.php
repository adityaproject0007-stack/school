<?php
session_start();
include("../backend/db.php");
$email=$_POST['email'];
$res=$conn->query("SELECT * FROM students WHERE email='$email'");
if($res->num_rows>0){$_SESSION['student']=$email;header("Location: dashboard.php");}
?>