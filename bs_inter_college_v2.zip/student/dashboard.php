<?php session_start(); if(!isset($_SESSION['student'])) die("Login First"); ?>
<h2>Student Dashboard</h2>
<p>Fees | Results | Notices</p>
